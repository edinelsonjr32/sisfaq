﻿/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'smiley', 'gu', {
	options: 'સમ્ય્લી વિકલ્પો',
	title: 'સ્માઇલી  પસંદ કરો',
	toolbar: 'સ્માઇલી'
} );
