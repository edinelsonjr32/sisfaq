﻿/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'stylescombo', 'tt', {
	label: 'Стильләр',
	panelTitle: 'Форматлау стильләре',
	panelTitle1: 'Блоклар стильләре',
	panelTitle2: 'Эчке стильләр',
	panelTitle3: 'Объектлар стильләре'
} );
